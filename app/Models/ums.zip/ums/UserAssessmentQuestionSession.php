<?php

namespace App\models\ums;
use Illuminate\Database\Eloquent\Model;

class UserAssessmentQuestionSession extends Model
{
	// question session
}
