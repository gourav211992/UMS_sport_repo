<?php

namespace App\models\ums;

use Illuminate\Database\Eloquent\Model;

class Department extends Model
{
   //public $table='departments';
}
