<?php

namespace App\models\ums;

use Illuminate\Database\Eloquent\Model;

class Notification extends Model
{
    //public $table="notifications";
   // public $timestamps=false;
}
