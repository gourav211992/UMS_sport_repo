<?php

namespace App\models\ums;

use Illuminate\Database\Eloquent\Model;

class Audit extends Model
{
    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */

    

}


