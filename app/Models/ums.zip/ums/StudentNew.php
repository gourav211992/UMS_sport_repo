<?php

namespace App\models\ums;

use Illuminate\Database\Eloquent\Model;

class StudentNew extends Model
{
    protected $table = 'students_new';
    public $timestamps = false;
}
