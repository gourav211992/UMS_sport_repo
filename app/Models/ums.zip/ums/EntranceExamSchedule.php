<?php

namespace App\models\ums;

use Illuminate\Database\Eloquent\Model;

class EntranceExamSchedule extends Model
{
    //
}
