<?php

namespace App\models\ums;

use Illuminate\Database\Eloquent\Model;

class AccountRole extends Model
{
    protected $table = 'roles';
}
