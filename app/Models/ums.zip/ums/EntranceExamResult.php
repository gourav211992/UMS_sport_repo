<?php

namespace App\models\ums;

use Illuminate\Database\Eloquent\Model;
//use Illuminate\Database\Eloquent\SoftDeletes;

class EntranceExamResult extends Model
{
//	use SoftDeletes;

    public $table="entrance_exams_result";


}
