<?php

namespace App\models\ums;

use Illuminate\Database\Eloquent\Model;

class ApplicationFees extends Model
{
    protected $table = 'application_fees';
}
