<?php

namespace App\models\ums;

use Illuminate\Database\Eloquent\Model;

class AccountOrganization extends Model
{
    protected $table = 'organizations';
}
